const help = (prefix) => {
	return `> *🔱𝗦𝘁𝗶𝗰𝗸𝗲𝗿 𝗹𝗼𝗿𝗱𝗲 𝘀𝗰𝗿𝗲𝗮𝗺𝗼 𝗖𝗼𝗺𝗮𝗻𝗱𝗼𝘀* 🔱 <
	
comando : *${prefix}sticker* or *${prefix}stiker*
desc : converter imagem / gif / vídeo em adesivo
uso : responder imagem / gif / vídeo ou enviar imagem / gif / vídeo com legenda\n
comando: *${prefix}sticker nobg* or *${prefix}stiker nobg*
desc : converter imagem em adesivo removendo o fundo
uso : responder imagem ou enviar imagem com legenda\n
comando : *${prefix}toimg*
desc : converter adesivo em imagem
uso : reply sticker\n
comando : *${prefix}tsticker* or *${prefix}tstiker*
desc : converter texto em adesivo
uso : *${prefix}tsticker text in here*\n

grupσ dσ вσt : https://chat.whatsapp.com/FPgLY4A3F6vJ8jXVZXHhNA

> 🔰𝗠𝗲𝗺𝗲 𝗖𝗼𝗺𝗮𝗻𝗱𝗼𝘀🔰<

comando : *${prefix}meme*
desc : imagens aleatórias de meme [english]
uso : apenas envie o comando\n
comando : *${prefix}memeindo*
desc : imagens aleatórias de meme [indo]
uso : apenas envie o comando\n

ɪɴsᴛᴀɢʀᴀᴍ : https://lordescreamo.blogspot.com/?m=1

> 🔰𝗢𝘂𝘁®𝗼𝘀 𝗖𝗼𝗺𝗮𝗻𝗱𝗼𝘀🔰<

comando : *${prefix}gtts*
desc : converter texto em fala/audio
usao : *${prefix}gtts [cc] [text]*\nexample : *${prefix}gtts ja On2-chan*\n
comando : *${prefix}loli*
desc : imagens aleatórias de loli
uso : apenas envie o comando\n
comando : *${prefix}nsfwloli*
desc :imagens aleatórias de nsfw loli
uso : apenas envie o comando\n
comando : *${prefix}url2img*
desc :tirar screenshots da web
uso : *${prefix}url2img [tipe] [url]*\n
comando : *${prefix}simi*
desc : esse comando buga simi
uso : *${prefix}simi yourmessage*\n
comando : *${prefix}ocr*
desc : pegue o texto na foto
uso : responder imagem ou enviar imagem com legenda\n
comando : *${prefix}wait*
desc : procure anime com imagem [ What Anime Is This/That ]
uso : responder imagem ou enviar imagem com legenda\n
comando : *${prefix}setprefix*
desc : replace prefix
uso : *${prefix}setprefix [text|optional]*\nexample : *${prefix}setprefix ?*
nota : Este comando só pode ser usado pelo proprietário do bot\n

> 🔰𝗚𝗿𝘂𝗽𝗼 𝗖𝗼𝗺𝗮𝗻𝗱𝗼𝘀🔰 <

númєrσ lσrdє ѕcrєαmσ : http://wa.me/+5522999982383

comando : *${prefix}kick*
desc : remove membros do grupo
usar : *${prefix}kick @tagmember*\n
nota : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin\n
comando : *${prefix}promote*
desc : tornar o membro do grupo como administrador do grupo
usar : *${prefix}promote @tagmember*\n
nota : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin!\n
comando : *${prefix}demote*
desc : tornar o administrador do grupo como membro do grupor
usar : *${prefix}demote @tagmember*\n
nota : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin!\n
comando : *${prefix}linkgroup*
desc : pegue o link do grupo
usar : apenas envie o comando
nota : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin!\n
comando : *${prefix}leave*
desc : bot sai do grupo
uso : apenas envie o comando
nota : Só pode ser usado por administradores de grupo e proprietário do bot!\n
comando : *${prefix}tagall*
desc : marca todos os membros do grupo, incluindo administradores também
usage : apenas envie o comando 
nota : Este comando pode ser usado se você for um administrador de grupo\n
command : *${prefix}simih*
desc : ative o modo simi no grupo isso buga
usage : *${prefix}simih 1* to activate simi mode and *${prefix}simih 0* to deactivate simi mode
note : comando Simi inútil so serve pra buga o Grupo \n`
}

exports.help = help
